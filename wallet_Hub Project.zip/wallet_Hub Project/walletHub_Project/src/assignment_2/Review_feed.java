package assignment_2;

import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;

import org.openqa.selenium.WebDriver;

import org.openqa.selenium.WebElement;

import org.openqa.selenium.chrome.ChromeDriver;

import org.openqa.selenium.interactions.Actions;

import org.testng.Assert;

import org.testng.annotations.AfterTest;

import org.testng.annotations.BeforeTest;

import org.testng.annotations.Test;

public class Review_feed 

{
	private static WebDriver driver = null;
	
	@BeforeTest
	public void Initialize() throws Exception 
		
		{	
		
		  //Set path for Chrome Driver executable
        
			System.setProperty("webdriver.chrome.driver","/home/goin/Documents/chromedriver");
     	
			driver = new ChromeDriver();
   
		 // Maximize Window
			driver.manage().window().maximize(); 
    
         // Wait For Page To Load
			driver.manage().timeouts().implicitlyWait(40, TimeUnit.SECONDS);
			
			//Navigate to given URL 
			  driver.get("https://wallethub.com/join/light");
    
		}
	
	
@Test(priority = 1)
public void login() throws Exception 
	
	{	
	
	try
	  {

  WebElement email = driver.findElement(By.xpath("//A[@href=''][text()='Login']/self::A"));
  
  System.out.println("E-mail Id field Exists \n"); 
  
  email.click();
  
  } 

	  catch(Throwable e) 

  {

  System.out.println("Login link Not Found : " + e.getMessage());   
  
  }
	
	try
	  {
 
    WebElement email = driver.findElement(By.name("em"));
    
    System.out.println("E-mail Id field Exists \n"); 
    
    email.sendKeys("");
    
    } 

	  catch(Throwable e) 

    {
 
    System.out.println("E-mail Id Not Found : " + e.getMessage());   
    
    }

	  //Check whether Password field exists or not
	  try

	  {
   
 	  WebElement password = driver.findElement(By.xpath("//INPUT[@type='password']/self::INPUT"));
   
 	  System.out.println("Password field Exits \n");
   
 	  password.sendKeys("");
   
	  } 

	  catch(Throwable e) 

	  {
   
	  System.out.println("Password not found: " + e.getMessage());
  
	  }
	
		
	 //Click on Join button
	   try
	    
	   		{
	         
		   	WebElement join = driver.findElement(By.xpath("//BUTTON[@type='button']/self::BUTTON"));
	        
		   	join.click();
		   	
		    Thread.sleep(5000);
		   
	        System.out.println("Login Button is clicked");
	                  
	   		} 
	 
	   catch(Throwable e) 
	 
	    	{
	         
		    System.out.println("Login button not found: " + e.getMessage());
	        
	    	}
	  
	 //Navigate to the given URL
	   try
	   {
		   driver.get("https://wallethub.com/profile/test_insurance_company/");
		   System.out.println("Given URL found");
	   }
	   
	   catch(Throwable e)
	   {
		   System.out.println(" Given URL not found: " + e.getMessage());
	   }
	     
	   try
	   {
		WebElement stars = driver.findElement(By.cssSelector("[class='wh-rating rating_5']"));
   
		WebElement srating5 = driver.findElement(By.xpath("//*[@class=\"wh-rating-choices-holder\"]/a[5]"));

		Actions builder = new Actions(driver);
   
		builder.moveToElement(stars).moveToElement(srating5).click().perform();
		
		System.out.println("5 star rating clicked");
	   }
	   
	   catch(Throwable e)
	   {
	   System.out.println("5 Star Rating not clicked: " + e.getMessage());
	   }
   
   //Policy dropdown
   try
   
		{
    
	   WebElement Policy_dropdown = driver.findElement(By.xpath("//*[@class='dropdown-title']"));
   
	   Policy_dropdown.click();
	   
	   Thread.sleep(1000);
	   System.out.println("Policy_dropdown clicked");
             
		} 

   catch(Throwable e) 

		{
    
	   System.out.println("Policy_dropdown not found: " + e.getMessage());
   
		}
   
   //Select Health
   try
   
		{

	   WebElement Health_option = driver.findElement(By.cssSelector("[data-target='Health']"));

	   Health_option.click();
	   
	   Thread.sleep(5000);  
	   
	   System.out.println("Health_option clicked");
		} 
   
   catch(Throwable e) 

		{

	   System.out.println("Health option not found: " + e.getMessage());

		}
   
   //5_Stars option
   try
   
		{

	   WebElement Click_5star = driver.findElement(By.xpath("//*[@onmouseover=\"try{gRatingsHover(this)}catch(e){}\"][5]"));

	   Click_5star.click();
	   
	   System.out.println("5 star rating clicked");
   
		} 

   catch(Throwable e) 

		{

	   System.out.println("Health option not found: " + e.getMessage());

		}
   
   //Write a review
   try
   
		{

	   WebElement Write_review = driver.findElement(By.id("review-content"));

	   Write_review.sendKeys("For example, there are few insurers who might not issue policy for diabetes," + 
			   " whereas there are few who does. There are chances that your current insurer" + 
			   " may not cover diabetes, however if you review it before renewing you might" +
			   " end one buying one which covers that disease");
	   
	   Thread.sleep(2000);
	   
	   System.out.println("Policy reviewed");

		} 

   catch(Throwable e) 

		{

	   System.out.println("Write_review option not found: " + e.getMessage());

		}
   
   //Submit_Button
   try
   
		{

	   WebElement Submit_Button = driver.findElement(By.xpath("//INPUT[@type='submit']/self::INPUT"));

	   Submit_Button.click();
	   
	   Thread.sleep(2000);
	   
	   System.out.println("Submit_Button clicked");

		} 

   catch(Throwable e) 

		{

	   System.out.println("Submit_Button option not found: " + e.getMessage());

		}
   
   //Confirm_Review
   try
   
		{
	   
	   driver.get("https://wallethub.com/profile/nagarjunaha/reviews/");

	   WebElement Confirm_Review = driver.findElement(By.tagName("p"));
		
		String Review = Confirm_Review.getText();
			
	   Assert.assertTrue(true, Review);
	   
	   System.out.println("Policy review statement present");

		} 

   catch(Throwable e) 

		{

  System.out.println("Review option not found: " + e.getMessage());

		}
  
	}

@AfterTest
public void Close() throws Exception

{ 

     driver.close();
     
     driver.quit();

}
}

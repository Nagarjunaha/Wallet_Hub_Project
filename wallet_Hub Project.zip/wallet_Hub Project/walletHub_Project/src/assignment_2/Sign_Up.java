package assignment_2;

import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.annotations.AfterTest;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.Test;

public class Sign_Up
{
	private static WebDriver driver = null;
	@BeforeTest
	public void Initialize() throws Exception 
		
		{	
		
		  //Set path for Chrome Driver executable
        
			System.setProperty("webdriver.chrome.driver","/home/goin/Documents/chromedriver");
     	
			driver = new ChromeDriver();
   
		 // Maximize Window
			driver.manage().window().maximize(); 
    
         // Wait For Page To Load
			driver.manage().timeouts().implicitlyWait(30, TimeUnit.SECONDS);
			
			//Navigate to given URL 
			  driver.get("https://wallethub.com/join/light");
    
		}
	
	
	@Test
	public void Sign_up () throws Exception 
		
		{
	
	  //Both User name and Password are entered correctly. Check whether Email field exists or not 
	  try
	  {
   
      WebElement email = driver.findElement(By.name("em"));
      
      System.out.println("E-mail Id field Exists \n"); 
      
      email.sendKeys("nagarjuna.ha@gmail.com");
      
      } 

	  catch(Throwable e) 

      {
   
      System.out.println("E-mail Id Not Found : " + e.getMessage());   
      
      }

	  //Check whether Password field exists or not
	  try

	  {
     
   	  WebElement password = driver.findElement(By.xpath("//INPUT[@type='password']/self::INPUT"));
     
   	  System.out.println("Password field Exits \n");
     
   	  password.sendKeys("1!Bahubali056");
     
	  } 

	  catch(Throwable e) 

	  {
     
	  System.out.println("Password not found: " + e.getMessage());
    
	  }

	  //Check whether confirm Password field exists or not
	  try

	  {
     
	   WebElement Confirmpassword = driver.findElement(By.xpath("(//INPUT[@type='password'])[2]"));
     
	   System.out.println("Confirm Password field Exits \n");
     
	   Confirmpassword.sendKeys("1!Bahubali056");
     
	  } 

	  catch(Throwable e) 

	  {
     
	   System.out.println("Password not found: " + e.getMessage());
    
	  }

	  //uncheckbox to get your free credit score and report.
	  try

	   {
     
   	    WebElement unchkbox = driver.findElement(By.xpath("//LABEL[@class='check']"));
    
   	    for (int i = 0;i<1;i++)
   	    {
   		unchkbox.click();
   	    }
   	    System.out.println("checkbox is unchecked");
              
		} 

	  catch(Throwable e) 

	  {
     
	   System.out.println("checkbox not found: " + e.getMessage());
    
	  }

	  //Click on Join button
	  try

	  {
     
   	   WebElement join = driver.findElement(By.xpath("//DIV[@class='btns']//BUTTON[@type='button']"));
    
   	   join.click();
   
   	   System.out.println("Join Button is clicked");
              
	   } 

	  catch(Throwable e) 

	  {
     
	   System.out.println("join button not found: " + e.getMessage());
    
	  }
	}
	
	@AfterTest
	public void Close() throws Exception

	{ 
	
	     driver.close();
	     
	     driver.quit();

	}
}
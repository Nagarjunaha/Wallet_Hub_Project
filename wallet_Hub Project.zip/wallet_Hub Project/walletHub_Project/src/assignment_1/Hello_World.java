package assignment_1;

import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;

import org.openqa.selenium.WebDriver;

import org.openqa.selenium.WebElement;

import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.chrome.ChromeOptions;
import org.testng.annotations.AfterTest;

import org.testng.annotations.BeforeTest;

import org.testng.annotations.Test;



public class Hello_World

    {
	
private static WebDriver driver = null;

@BeforeTest
public void beforeTest() throws Exception 
	
	{		
		
		//Set path for Chrome Driver executable
	
		ChromeOptions chrome_Profile = new ChromeOptions();
		
		chrome_Profile.addArguments("chrome.switches","--disable-extensions"); 
		
		chrome_Profile.addArguments("--disable-save-password");
		
		chrome_Profile.addArguments("disable-infobars");

     	System.setProperty("webdriver.chrome.driver","/home/goin/Documents/chromedriver");
     	
     	WebDriver driver =new ChromeDriver(chrome_Profile);

        driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);

        driver.get("https://www.facebook.com/"); 
    
	}
    
 //-------------------------------------------------------------------------------------------------------          

@Test
public void Test() throws Exception 
	 
	{	
		
    //Both User name and Password are entered correctly. Check whether Email field exists or not */
   try
        {
	   
          WebElement email = driver.findElement(By.id("email"));
          
          System.out.println("E-mail Id field Exists \n"); 
          
          email.sendKeys("");
          
          } 
   
   catch(Throwable e) 
   
          {
	   
          System.out.println("E-mail Id field Not Found : " + e.getMessage());   
          
          }
   
    //Check whether Password field exists or not
   try
    
   		{
         
	   	WebElement password = driver.findElement(By.id("pass"));
         
        System.out.println("Password field Exits \n");
         
        password.sendKeys("");
         
   		} 
 
   catch(Throwable e) 
 
    	{
         
	    System.out.println("Password field not found: " + e.getMessage());
        
    	}
   
   //Click on Log in button
   try
   
  		{
        
	   	WebElement log_in_button = driver.findElement(By.id("loginbutton"));
        
       System.out.println("log_in_button Exists \n");
        
       log_in_button.click();
        
  		} 

  catch(Throwable e) 

   	{
        
	    System.out.println("log_in_button not found: " + e.getMessage());
       
   	}
    
//Post a status message "Hello World"
   try
   		{
   
	   	WebElement Status_message = driver.findElement(By.cssSelector("textarea[title*='Write something here...']"));
   
	   	Status_message.sendKeys("Hello World");
   
	   	WebElement Post = driver.findElement(By.xpath("//BUTTON[@class='_1mf7 _4jy0 _4jy3 _4jy1 _51sy selected _42ft']/self::BUTTON"));
   
	   	Post.click();
   
	   	System.out.println("Posted status message as Hello World");
   
   		}
   
   catch(Throwable e)
   		{
	   		
	   		System.out.println("Status posting failed: "+e.getMessage());
	   		
   		}
   
   //Clicking on the Logout button.
   try
   		{    
    
	   WebElement Logout_1 = driver.findElement(By.id("userNavigationLabel"));
        
	   Logout_1.click();
	   
	   WebElement Logout_2 = driver.findElement(By.linkText("Log Out"));
       
	   Logout_2.click();
	   
   		}
   
   catch(Throwable e)    
   		{
    
	   System.out.println("Logout not found: "+e.getMessage());
    
   		}
   
    }
	
	@AfterTest
	public void Close() throws Exception

	{ 
	
	     driver.close();
	     
	     driver.quit();

	}

}
